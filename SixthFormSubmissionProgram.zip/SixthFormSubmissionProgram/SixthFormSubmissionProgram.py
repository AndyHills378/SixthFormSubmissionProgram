from tkinter import *
import tkinter.ttk as ttk
import sqlite3 as lite
import tkinter as tk
from collections import Counter

conn = lite.connect("SQL database for GCSE students.db")
cur = conn.cursor()

class getStudentGrades(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.config(bg="#4695b9")
        self.geometry("250x150")
        self.title("Input Grades")
        self.resizable(0,0)
        try:
            self.SelectedItem = fnSelectStudentAdmissionNo()
        except:
            mylabel2 = tk.Label(self, text="No Student Selected", bg="#4695b9", fg="white").place(x=105,y=10)
            self.SelectedItem = None
            
        self.lblAdminNo = tk.Label(self, text="AdmissionNo:", bg="#4695b9", fg="white").place(x=10,y=10)

        self.lblValidate = tk.Label(self, text=self.SelectedItem, bg="#4695b9", fg="white").place(x=100,y=10)

        self.myComboSubjectboxVal = StringVar()
        self.myComboSubjectbox = ttk.Combobox(self,textvariable=self.myComboSubjectboxVal, width=22,height=4, background="white", state=DISABLED)
        self.myComboSubjectbox['values'] = ("Art & Design","Business","Childcare","Computer Science","Dance","Double Science","Drama","Economics","English Language",\
                          "English Literature","French","Further Mathematics","Geography","German","Graphic Communication","Health & Social Care",\
                          "History","Hospitality & Catering","ICT","Mandarin","Mathematics","Media","Performing Arts","P.E. (GCSE)","Product Design",\
                          "R.E.","Textiles & Fashion","Triple Science")
        self.myComboSubjectbox.place(x=85,y=40)
        self.lblSelect = tk.Label(self, text="Subject:", bg="#4695b9", fg="white").place(x=10,y=40)


        self.myComboGradeboxVal = StringVar()
        self.myComboGradebox = ttk.Combobox(self,textvariable=self.myComboGradeboxVal, width=6,height=4, background="white", state=DISABLED)
        self.myComboGradebox['values'] = ("A*","A","B","C","D","E","U","9","8","7","6","5","4","3","2","1","0")
        self.myComboGradebox.place(x=85,y=70)
        self.lblGrade = tk.Label(self, text="Grade:", bg="#4695b9", fg="white").place(x=10,y=70)

        self.BtnAppend = tk.Button(self, text="Add", bg="#939598", fg="white",command=self.fnGetStudentGrades, state=DISABLED)
        self.BtnAppend.place(x=10,y=100)


        if self.SelectedItem == None:
            self.myComboSubjectbox.config(state=DISABLED)
            self.myComboGradebox.config(state=DISABLED)
            self.BtnAppend.config(state=DISABLED)
        elif self.SelectedItem != None:
            self.myComboSubjectbox.config(state=NORMAL)
            self.myComboGradebox.config(state=NORMAL)
            self.BtnAppend.config(state=NORMAL)

            


    def fnGetStudentGrades(self):
        ('''This function takes the user input of a students grades and then converts it into SQL format
            to be inputted into the database''')
        AdmissionNo = self.SelectedItem
        Subject = self.myComboSubjectbox.get()
        Grade = self.myComboGradebox.get()
        table_list = []
        Found = False
        cur.execute("SELECT * FROM Subject")
        for row in cur:
            table_list.append((row[0], row[1]))
        for item in table_list:
            if Subject == item[1]:
                Subject = int(item[0])
                Found = True
        if Found == False:
            self.lblValidate2 = tk.Label(self, text="Invalid", bg="#4695b9", fg="white").place(x=70,y=100)
        elif Found == True:
            cur.execute("INSERT INTO Grade Values(?,?,?)", (AdmissionNo,Subject,Grade))
            conn.commit()
        
class getStudentDetails(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.config(bg="#4695b9")
        self.geometry("310x170")
        self.title("Input Student")
        self.resizable(0,0)
        
        self.txtEntry1 = tk.Entry(self)
        self.lblFName = tk.Label(self, text="First Name:", bg="#4695b9", fg="white").place(x=10,y=10)
        self.txtEntry1.place(x=80,y=10)

        self.txtEntry2 = tk.Entry(self)
        self.lblLName = tk.Label(self, text="Last Name:", bg="#4695b9", fg="white").place(x=10,y=40)
        self.txtEntry2.place(x=80,y=40)

        self.lblDOB = tk.Label(self, text="DOB(YYYY,MM,DD):", bg="#4695b9", fg="white").place(x=10,y=70)
        self.SpinYrVal = tk.Spinbox(self, from_=2000, to=2040,width=5, font=("",10),background="white")
        self.SpinYrVal.place(x=130,y=70)        

        self.SpinMonthval = tk.Spinbox(self, from_=1, to=12,width=5, font=("",10),background="white")
        self.SpinMonthval.place(x=190,y=70)    

        self.SpinDayVal = tk.Spinbox(self, from_=1, to=31,width=5, font=("",10),background="white")
        self.SpinDayVal.place(x=250,y=70)

        self.lblYrOfEntry = tk.Label(self, text="Year Of Entry:", bg="#4695b9", fg="white").place(x=10, y=100)
        self.SpinEntryVal = tk.Spinbox(self, from_=2017, to=2040,width=5, font=("",10),background="white")
        self.SpinEntryVal.place(x=90,y=100)         

        self.lblAdminNo = tk.Label(self, text="AdmissionNo: ", bg="#4695b9", fg="white").place(x=50,y=130)

        self.BtnAppend = tk.Button(self, text="Add", bg="#939598", fg="white", command=self.fnGetStudentDetails)
        self.BtnAppend.place(x=10,y=130)
        

    def fnGetStudentDetails(self):
        ('''This function takes the user input of a students details and then converts it into SQL format
            to be inputted into the database''')
        table_list = []
        AdmissionNo = None
        DOB = self.SpinDayVal.get()+"/"+self.SpinMonthval.get()+"/"+self.SpinYrVal.get()
        YrOfEntry = self.SpinEntryVal.get()
        try:
            FirstName = str(self.txtEntry1.get())
            SurName = str(self.txtEntry2.get())
            cur.execute("INSERT INTO Student Values(?,?,?,?,?)", (AdmissionNo,FirstName,SurName,DOB,YrOfEntry))
            conn.commit()
            cur.execute("SELECT * FROM Student")
            for row in cur:
                table_list.append(row[0])
            self.lblAdminNo = tk.Label(self, text=table_list[len(table_list)-1], bg="#4695b9", fg="white").place(x=130,y=130)
        except:
            self.lblValidate = tk.Label(self, text="Not a valid name").place(x=120,y=25)



class EditStudentDetails(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.config(bg="#4695b9")
        self.geometry("250x150")
        self.title("Edit student details")
        self.resizable(0,0)

        try:
            self.SelectedItem = fnSelectStudentAdmissionNo()
        except:
            lblValidate1 = tk.Label(self, text="No Student Selected", bg="#4695b9", fg="white").place(x=105,y=10)
            self.SelectedItem = None

        self.lblAdminNo = tk.Label(self, text="AdmissionNo:", bg="#4695b9", fg="white").place(x=10,y=10)
        self.lblValidate2 = tk.Label(self, text=self.SelectedItem, bg="#4695b9", fg="white").place(x=100,y=10)
        
        self.txtEntry1 = tk.Entry(self, state=DISABLED)
        self.lblFName = tk.Label(self, text="First Name:", bg="#4695b9", fg="white").place(x=10,y=40)
        self.txtEntry1.place(x=100,y=40)

        self.txtEntry2 = tk.Entry(self,state=DISABLED)
        self.lblLName = tk.Label(self, text="Last Name:", bg="#4695b9", fg="white").place(x=10,y=70)
        self.txtEntry2.place(x=100,y=70)

        self.BtnEdit = tk.Button(self, text="Edit", bg="#939598", fg="white", command=self.fnChangeStudentInfo, state=DISABLED)
        self.BtnEdit.place(x=10,y=100)
        
        if self.SelectedItem == None:
            self.txtEntry1.config(state=DISABLED)
            self.txtEntry2.config(state=DISABLED)
            self.BtnEdit.config(state=DISABLED)
        elif self.SelectedItem != None:
            self.txtEntry1.config(state=NORMAL)
            self.txtEntry2.config(state=NORMAL)
            self.BtnEdit.config(state=NORMAL)


    def fnChangeStudentInfo(self):
        ('''This function reads a users input and then changes a specific students details in the SQL database''')
        AdmissionNo = self.SelectedItem
        FirstName = self.txtEntry1.get()
        LastName = self.txtEntry1.get()
        cur.execute("UPDATE Student SET FirstName = ?, SurName = ? WHERE AdmissionNo = ?", (FirstName,LastName,AdmissionNo))
        conn.commit()   
        

class EditStudentGrades(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.config(bg="#4695b9")
        self.geometry("250x150")
        self.title("Edit student grades")
        self.resizable(0,0)

        try:
            self.SelectedNumber = fnSelectStudentAdmissionNo()
            self.SelectedSubject = fnSelectStudentSubject()
        except:
            lblValidate1 = tk.Label(self, text="No Student Selected", bg="#4695b9", fg="white").place(x=105,y=10)
            lblValidate2 = tk.Label(self, text="No Student Selected", bg="#4695b9", fg="white").place(x=105,y=40)
            self.SelectedNumber = None
            self.SelectedSubject = None
            
        self.lblAdminNo = tk.Label(self, text="AdmissionNo:", bg="#4695b9", fg="white").place(x=10,y=10)
        self.lblSubject = tk.Label(self, text="Subject:", bg="#4695b9", fg="white").place(x=10,y=40)
        self.lblValidate3 = tk.Label(self,text=self.SelectedNumber, bg="#4695b9", fg="white").place(x=100,y=10)
        self.lblValidate4 = tk.Label(self,text=self.SelectedSubject, bg="#4695b9", fg="white").place(x=100,y=40)

        self.myComboGradeboxVal = StringVar()
        self.myComboGradebox = ttk.Combobox(self,textvariable=self.myComboGradeboxVal, width=6,height=4, background="white", state=DISABLED)
        self.myComboGradebox['values'] = ("A*","A","B","C","D","E","U","9","8","7","6","5","4","3","2","1","0")
        self.myComboGradebox.place(x=100,y=70)
        self.lblGrade = tk.Label(self, text="Grade:", bg="#4695b9", fg="white").place(x=10,y=70)

        self.BtnEdit = tk.Button(self, text="Edit", bg="#939598", fg="white", command=self.fnChangeStudentInfo, state=DISABLED)
        self.BtnEdit.place(x=10,y=100)

        if self.SelectedNumber == None and self.SelectedSubject == None:
            self.myComboGradebox.config(state=DISABLED)
            self.BtnEdit.config(state=DISABLED)
        elif self.SelectedNumber != None and self.SelectedSubject != None:
            self.myComboGradebox.config(state=NORMAL)
            self.BtnEdit.config(state=NORMAL)                

    def fnChangeStudentInfo(self):
        ('''This function reads a users input and then changes a specific students grades in the SQL database''')
        Subject_list = []
        Grades = self.myComboGradebox.get()
        AdmissionNo = self.SelectedNumber
        SubjectID = self.SelectedSubject
        cur.execute("SELECT * FROM Subject")
        for row in cur:
            Subject_list.append((int(row[0]), row[1]))
        for item in Subject_list:
            if SubjectID == item[1]:
                SubjectID = int(item[0])
        cur.execute("UPDATE Grade SET Grades = ? WHERE AdmissionNo = ? AND SubjectID = ?", (Grades, AdmissionNo, SubjectID))
        conn.commit()         
                                                          
def fnInsertStudentDetails():
    StudentDetails = getStudentDetails()
    StudentDetails.mainloop()  
   
def fnInsertStudentGrades():
    StudentGrades = getStudentGrades()
    StudentGrades.mainloop()

def fnEditStudentDetails():
    StudentDetails = EditStudentDetails()
    StudentDetails.mainloop()

def fnEditStudentGrades():
    StudentGrades = EditStudentGrades()
    StudentGrades.mainloop()

def fnBulkImport():
    ('''This function allows the program to read from a CSV file and then input all data stored in the file into
        the SQL database''')
    table_list = []
    checkList = []
    checkList2 = []   
    readFile=open("StudentImport.csv", "r")
    for row in readFile:
        line=row.strip().split(",")
        table_list.append((line[0],line[1],line[2],line[3],line[4],line[5],line[6]))
    readFile.close()
    table_list.remove(table_list[0])
    for item in table_list:
        StudentID = int(item[0])
        FirstName = item[1]
        LastName = item[2]
        SubjectID = item[3]
        Grade = item[4]
        DOB = item[5]
        YrOfEntry = item[6]
        cur.execute("SELECT AdmissionNo FROM Student")
        for row in cur:
            checkList.append(row[0])
        if StudentID in checkList:
            cur.execute("INSERT INTO Grade Values(?,?,?)", (StudentID, Grade, SubjectID))
        else:
            cur.execute("INSERT INTO Student Values(?,?,?,?,?)",(StudentID, FirstName, LastName, DOB, YrOfEntry))
            cur.execute("INSERT INTO Grade Values(?,?,?)", (StudentID, Grade, SubjectID))
        conn.commit()
        readFile.close()  
        
def fnMergeSort(alist):
    ('''This function allows the program to sort the data retrieved into order by the students AdmissionNo''')
    if len(alist)>1:
        mid = len(alist)//2
        lefthalf = alist[:mid]
        righthalf = alist[mid:]
        fnMergeSort(righthalf)
        fnMergeSort(lefthalf)
        i=0
        j=0
        k=0
        while i < len(lefthalf) and j < len(righthalf):
            if lefthalf[i] < righthalf[j]:
                alist[k]=lefthalf[i]
                i=i+1
            else:
                alist[k]=righthalf[j]
                j=j+1
            k=k+1
        while i < len(lefthalf):
            alist[k]=lefthalf[i]
            i=i+1
            k=k+1
        while j < len(righthalf):
            alist[k]=righthalf[j]
            j=j+1
            k=k+1

def fnCreateStudentList():
    ('''This function allows the program to retrieve all data from the database stored in the Student table''')
    fnDeleteAll()
    boxValue.set('') 
    table_list = []
    cur.execute("SELECT * FROM Student")
    for row in cur:
        table_list.append((row[0], row[1], row[2], " ", " ", row[4]))
    fnMergeSort(table_list)
    for item in table_list:
        tree.insert('', 'end', values=item)
    lblTblLength.config(text="Records: "+str(len(tree.get_children())))
    
def fnCreateList():
    ('''This function allows the program to retrieve all data from the database that shows the user the
        required information''')
    fnDeleteAll()
    boxValue.set(" ")
    table_list = []
    cur.execute('''SELECT Grade.AdmissionNo, Grades, FirstName, SurName, EntryYear, Name
                   FROM  Grade, Student, Subject
                   WHERE Grade.AdmissionNo = Student.AdmissionNo 
                   AND Grade.SubjectID = Subject.SubjectID''')
    for row in cur:
        table_list.append((row[0], row[2], row[3], row[1], row[5], row[4]))
    fnMergeSort(table_list)
    for item in table_list:
        tree.insert('', 'end', values=item)
    lblTblLength.config(text="Records: "+str(len(tree.get_children())))

def fnLinearSearchList(getInp, char, position):
    ('''This function allows the program to search through the table list on the interface and then output
        based on the records that are found''')
    aList = []
    newList = []
    for child in tree.get_children(''):
        aList.append((tree.set(child,0),tree.set(child,1),tree.set(child,2),tree.set(child,3),tree.set(child,4),tree.set(child,5)))
    fnResetBox()
    count = 0
    found = 0
    while count < len(aList):
        if aList[count][position][:char] == getInp:            
            newList.append(aList[count])
            found = found + 1
        count = count + 1
    if found >= 1:
        lblTblLength.config(text="Records: "+str(found))
    elif found == 0:
        lblTblLength.config(text="Records: Filter not valid")
    for item in newList:
        tree.insert('', 'end', values=item)
    

def fnSearchGrade():
    ('''This function calls the LinearSearch function but calling for a specific grade''')
    EntryReq = ['A*','A','B','C','9','8','7','6','5']
    aList = []
    newList = []
    AdminList = []
    getInp = boxGradeVal.get()
    count = 0
    if getInp == "Entry Requirements":
        for Item in EntryReq:
            for child in tree.get_children(''):
                aList.append((tree.set(child,0),tree.set(child,1),tree.set(child,2),tree.set(child,3),tree.set(child,4),tree.set(child,5)))
            fnResetBox()
            count = 0
            found = 0
            while count < len(aList):
                if aList[count][3][:2] == Item:            
                    newList.append(aList[count])
                    found += 1
                count += 1
            if found >= 1:
                lblTblLength.config(text="Records: "+str(found))
            elif found == 0:
                lblTblLength.config(text="Records: Filter not valid")
##        print("Count for 28: ", newList[1].count('28'))
##        cnt = Counter()
##        for AdminNo in newList:
##            AdminList.append(AdminNo[0])
##        for item in AdminList:
##            cnt[item] += 1
##        print(cnt)
        for item in newList:
            tree.insert('', 'end', values=item)
    else:
        lenInp = len(getInp)
        fnLinearSearchList(getInp, lenInp, 3)
        

def fnSearchSubject():
    ('''This function calls the LinearSearch function but calling for a specific subject''')
    getInp = boxSubject.get()
    lenInp = len(getInp)
    fnLinearSearchList(getInp, lenInp, 4)

def fnSearchInitial():
    ('''This function calls the LinearSearch function but calling for a specific student's initial''')
    getInp = boxValue.get()
    fnLinearSearchList(getInp, 1, 2)

def fnSearchName():
    ('''This function calls the LinearSearch function but calling for a specific surname''')
    getInp = searchVal.get()
    lenInp = len(getInp)
    fnLinearSearchList(getInp, lenInp , 2)    
        
def fnSearchAdmissionNo():
    ('''This function calls the LinearSearch function but calling for a specific student''')
    getInp = spinVal.get()
    fnLinearSearchList(getInp, 4, 5)

def fnApplyFilter():
    if checkChoice1.get() == 1:
        fnSearchAdmissionNo()
    if checkChoice2.get() == 1:
        fnSearchName()
    if checkChoice3.get() == 1:
        fnSearchInitial()
    if checkChoice4.get() == 1:
        fnSearchGrade()       
    if checkChoice5.get() == 1:
        fnSearchSubject()
    lblSelectVal.set("Selected: None")
    fnClearSearch()

        
def fnSelectItem():
    ('''This function enables the user to select a student from the interface and then manipulate the data
        stored on that student as they wish''')
    try:
        items = tree.item(tree.selection())
        selectedItem = ("Selected: "+items["values"][1]+" "+items["values"][2]+", "+items["values"][4])
    except:
        selectedItem = ("Selected: None")
    lblSelectVal.set(selectedItem)   

def fnSelectStudentAdmissionNo():
    items = tree.item(tree.selection())
    return items["values"][0]

def fnSelectStudentSubject():
    items = tree.item(tree.selection())
    return items["values"][4]

def fnDeleteItem():
    ('''This function enables the user to delete a student's information from the database permanently''')
    table_list = []
    if  lblSelectVal.get() != "Selected: None":        
        try:
            items = tree.item(tree.selection())
            if items["values"][4] != " ":
                cur.execute("SELECT * FROM Subject")
                for row in cur:
                    table_list.append((row[0], row[1]))
                    
                AdmissionNo = items["values"][0]
                Subject = items["values"][4]
                for items in table_list:
                    if Subject == items[1]:
                        Subject = items[0]
                
                selectedItem = tree.selection()[0]
                tree.delete(selectedItem)
                cur.execute("DELETE FROM Grade WHERE AdmissionNo = ? AND SubjectID = ?", (AdmissionNo, Subject))
            elif items["values"][4] == " ":
                AdmissionNo = items["values"][0]
                FirstName = items["values"][1]
                selectedItem = tree.selection()[0]
                tree.delete(selectedItem)
                cur.execute("DELETE FROM Student WHERE AdmissionNo = ? AND FirstName = ?", (AdmissionNo, FirstName))
            conn.commit()                
            selectedItem = "Deleted: "+items["values"][1]+" "+items["values"][2]          

        except:
            selectedItem = "Deleted: None"
        lblTblLength.config(text="Records: "+str(len(tree.get_children())))   
        lblSelectVal.set(selectedItem)    
    
def fnDeleteAll():
    tree.delete(*tree.get_children())
    lblTblLength.config(text="Records: 0")
    boxValue.set('')
    fnEnableFilter()
    spinVal.set(2017)
    searchVal.set('')
    box.set('')
    boxGrade.set('')
    boxSubject.set('')
    fnClearSearch()

def fnResetBox():   
    tree.delete(*tree.get_children())
    lblTblLength.config(text="Records: 0")

def fnEnableFilter():
    if checkChoice1.get() == 1:
        spinbox.config(state=NORMAL)
    if checkChoice2.get() == 1:
        searchBox.config(state=NORMAL)
    if checkChoice3.get() == 1:
        box.config(state = "readonly")
    if checkChoice4.get() == 1:
        boxGrade.config(state = "readonly")
    if checkChoice5.get() == 1:
        boxSubject.config(state = "readonly")        

def fnquitProgram():
    myExit =messagebox.askyesno(title="Quit",message="Are you sure you want to quit?")
    if myExit > 0:
        root.destroy()
    return

def fnaboutProgram():
    myAboutMessage =messagebox.showinfo("DataBase Editor Version 1.0", "Beauchamp College | AH 2016")
    return    

def fnClearSearch():
    ('''This function enables to reselect the search criteria on the main interface''')
    checkChoice1.set(0)
    checkChoice2.set(0)
    checkChoice3.set(0)
    checkChoice4.set(0)
    checkChoice5.set(0)
    searchVal.set('')
    spinVal.set(2017)        
    box.set('')
    boxGrade.set('')
    boxSubject.set('')
    searchBox.config(state=DISABLED)
    spinbox.config(state=DISABLED)
    box.config(state=DISABLED)
    boxGrade.config(state=DISABLED)
    boxSubject.config(state=DISABLED)
    

root = Tk()
root.config(bg="white")

table_header = [' Admission No.', ' First Name',' Last Name',' Grade',' Subject','Entry Year']
container = Frame()
container.place(x=265,y=130)
tree = ttk.Treeview(columns=table_header,show="headings")
vsb = Scrollbar(orient="vertical", command=tree.yview)
tree.configure(yscrollcommand=vsb.set)
tree.grid(column=0, row=0, in_=container)

vsb.grid(column=1, row=0, sticky='ns', in_=container)
container.grid_columnconfigure(0, weight=1)
container.grid_rowconfigure(0, weight=1)

tree.column(table_header[0],width=87)
tree.column(table_header[1],width=87)
tree.column(table_header[2],width=87)
tree.column(table_header[3],width=50)
tree.column(table_header[4],width=140)
tree.column(table_header[5],width=70)

for col in table_header:
    tree.heading(col, text=col.title())

backCanvas= Canvas(root, background = "#4695b9")
backCanvas.place(x=0,y=0, width = 800, height = 105)

Photo1 = PhotoImage(file="BClogo.gif")
myPhoto1 = backCanvas.create_image(745,53,image=Photo1)


lblTitle = Label(root,text = "Database Editor", bg="#4695b9", fg="white", font=("Helvetica", 20, "bold"))
lblTitle.place(x=10,y=10)

lblDbTitle = Label(root,text = "File: SQL database for GCSE students.db", bg="#4695b9", fg="white", font=("Open_sansregular",9))
lblDbTitle.place(x=20,y=45)

lblTblLength = Label(root,text = "Records: 0", bg="#4695b9", fg="white", font=("Open_sansregular",9))
lblTblLength.place(x=20,y=60)

lblSelectVal = StringVar()
lblSelectVal.set('Selected: None')
lblSelect = Label(root,textvariable=lblSelectVal, bg="#4695b9", fg="white", font=("Open_sansregular",9))
lblSelect.place(x=20,y=75)

frameCanvas= Canvas(root)
frameCanvas.config(bg="white")
frameCanvas.place(x=2,y=150, width = 255, height = 145)
frameCanvas.create_rectangle(1, 1, 253, 143, fill='',width = 3,outline="grey")

lblSearch = Label(root,text = " Search ", bg="white", fg="#4695b9")
lblSearch.place(x=10,y=140)

BtnSlctItm = tk.Button(root, text = "Select Item", bg="#939598", fg="white", width = 14,command = fnSelectItem)
BtnSlctItm.place(x=5,y=110)

searchVal = StringVar()
searchBox = Entry(root,textvariable=searchVal, width=22, background="white", state=DISABLED)
searchBox.place(x=100,y=188)
searchVal.set('')

spinVal = StringVar()
spinbox = Spinbox(root, from_=2017, to=2040,width=5, font=("",10), textvariable=spinVal, background="white", state=DISABLED)
spinbox.place(x=125,y=165)

boxValue = StringVar()
box = ttk.Combobox(root,textvariable=boxValue, width=5, height = 4, background="white", state=DISABLED)
box['values'] = ('A','B','C','D','E','F','G','H','I','J','K','L','M','N',\
                 'O', 'P', 'Q','R','S','T','U','V','W','X','Y','Z')
box.place(x=130,y=213)

boxGradeVal = StringVar()
boxGrade = ttk.Combobox(root,textvariable=boxGradeVal, width=18, height = 4, background="white", state=DISABLED)
boxGrade['values'] = ('Entry Requirements','A*','A','B','C','D','E','F','U','9','8','7','6','5','4','3','2','1','0')
boxGrade.place(x=95,y=238)

boxSubjectVal = StringVar()
boxSubject = ttk.Combobox(root,textvariable=boxSubjectVal, width=22,height=4, background="white", state=DISABLED)
boxSubject['values'] = ("Art & Design","Business","Childcare","Computer Science","Dance","Double Science","Drama","Economics","English Language",\
                  "English Literature","French","Further Mathematics","Geography","German","Graphic Communication","Health & Social Care",\
                  "History","Hospitality & Catering","ICT","Mandarin","Mathematics","Media","Performing Arts","P.E. (GCSE)","Product Design",\
                  "R.E.","Textiles & Fashion","Triple Science")
boxSubject.place(x=95,y=263)

checkChoice1 = IntVar()
checkChoice2 = IntVar()
checkChoice3 = IntVar()
checkChoice4 = IntVar()
checkChoice5 = IntVar()  
Checkbutton(root, text="Entry Year", variable=checkChoice1,command = fnEnableFilter, bg="white", fg="#4695b9", font=("Open_sansregular",9)).place(x=10, y=160)
Checkbutton(root, text="Last Name", variable=checkChoice2,command = fnEnableFilter, bg="white", fg="#4695b9", font=("Open_sansregular",9)).place(x=10, y=185)
Checkbutton(root, text="Initial (Surname)", variable=checkChoice3,command = fnEnableFilter, bg="white", fg="#4695b9", font=("Open_sansregular",9)).place(x=10, y=210)
Checkbutton(root, text="Grade", variable=checkChoice4,command = fnEnableFilter, bg="white", fg="#4695b9", font=("Open_sansregular",9)).place(x=10, y=235)
Checkbutton(root, text="Subject", variable=checkChoice5,command = fnEnableFilter, bg="white", fg="#4695b9", font=("Open_sansregular",9)).place(x=10, y=260)

BtnApply = tk.Button(root, text = "Apply", bg="#939598", fg="white",width = 12,command = fnApplyFilter)
BtnApply.place(x=161,y=300)

BtnClear = tk.Button(root, text = "Clear Search", bg="#939598", fg="white",width = 12, command = fnClearSearch)
BtnClear.place(x=3,y=300)

MenuBar = Menu(root)
FileMenu = Menu(MenuBar,tearoff=0)
DeleteMenu = Menu(MenuBar, tearoff=0)
InsertMenu = Menu(MenuBar, tearoff=0)
EditMenu = Menu(MenuBar, tearoff=0)
ImportMenu = Menu(MenuBar, tearoff=0)

MenuBar.add_cascade(label="File", menu=FileMenu)
FileMenu.add_command(label="Load Students with Grades", command=fnCreateList)
FileMenu.add_command(label="Load all Students", command=fnCreateStudentList)
FileMenu.add_command(label="Close", command=fnquitProgram)
FileMenu.add_separator()
FileMenu.add_command(label="About", command=fnaboutProgram)

MenuBar.add_cascade(label="Edit",menu=EditMenu)
EditMenu.add_command(label="Edit Student",command=fnEditStudentDetails)
EditMenu.add_command(label="Edit Grades",command=fnEditStudentGrades)

MenuBar.add_cascade(label="Delete", menu=DeleteMenu)
DeleteMenu.add_command(label="Delete Item", command=fnDeleteItem)

MenuBar.add_cascade(label="Insert", menu=InsertMenu)
InsertMenu.add_command(label="Student Details", command=fnInsertStudentDetails)
InsertMenu.add_command(label="Student Grades", command=fnInsertStudentGrades)

MenuBar.add_cascade(label="Import", menu=ImportMenu)
ImportMenu.add_command(label="Bulk Import", command=fnBulkImport)
root.config(menu=MenuBar)


w = 810
h = 380
sw = root.winfo_screenwidth()
sh = root.winfo_screenheight()
x = (sw - w)/2
y = (sh - h)/2
root.geometry('%dx%d+%d+%d' % (w,h,x,y))
root.title("")
root.resizable(0,0)
root.protocol("WM_DELETE_WINDOW", fnquitProgram)
root.mainloop()
